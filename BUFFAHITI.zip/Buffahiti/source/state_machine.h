

#ifndef STATE_MACHINE_H_
#define STATE_MACHINE_H_


#include "led.h"


void Loop();
#endif /* STATE_MACHINE_H_ */
