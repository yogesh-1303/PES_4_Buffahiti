
typedef uint32_t ticktime_t;
void Init_SysTick();
void SysTick_Handler();
ticktime_t time_now();
void reset_timer();
ticktime_t get_timer();

