#ifdef DEBUG

#define LOG PRINTF

#else

#define LOG(...)

#endif
