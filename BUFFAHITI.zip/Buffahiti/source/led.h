


void led_init();			//provides cock to Port B and D, sets MUX values for GPIO, sets direction of GPIO pins as output
void led_on(int num);		//function that turns on the appropriate led.
void led_off();				//function that turns off the led.
